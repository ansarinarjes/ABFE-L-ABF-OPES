
proc calc_colvar_forces { ts } {
  #  puts "Running calc_colvar_forces at timestep $ts"
  set k 10

  set l [cv colvar l value]

  set cnum [cv colvar cnum value]
  if { $l > 0.05 && $l < 0.95 } {
    cv colvar cnum addforce [expr -$k*($cnum)]
  }
}

